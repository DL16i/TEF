/* JustFloat.h */
#ifndef __JUSTFLOAT_H
#define __JUSTFLOAT_H

#include <stdint.h>

void JustFloat_SendFloat(float a[], uint8_t num);

#endif