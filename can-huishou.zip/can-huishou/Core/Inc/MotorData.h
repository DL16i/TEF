/* MotorData.h */
#ifndef __MOTORDATA_H
#define __MOTORDATA_H

#include <stdint.h>

/* shuju*/
typedef struct {
    uint16_t ecd;
    int16_t  speed_rpm;
    int16_t  given_current;
    uint8_t  temperature;
    int16_t  last_ecd;
} motor_measure_t;

/* id */
#define M3508_ID_1  0x201
#define M3508_ID_2  0x202
#define M3508_ID_3  0x203
#define M3508_ID_4  0x204

#endif