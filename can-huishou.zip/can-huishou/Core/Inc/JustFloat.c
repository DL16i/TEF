/* JustFloat.c */
#include "stm32f4xx_hal.h"
#include "string.h"
#include "JustFloat.h"

extern UART_HandleTypeDef huart7;

uint8_t jfTxBuf[20];  // 
uint8_t jfBusy = 0;   // DMA ?????

void JustFloat_SendFloat(float a[], uint8_t num)
{
    if (jfBusy) return; // 

    uint8_t i, p = 0;
    memcpy(&jfTxBuf[p], (uint8_t[]){0x07, 0x05, 0x06}, 3); p += 3; // 

    for (i = 0; i < num; i++) {
        memcpy(&jfTxBuf[p], &a[i], 4); 
        p += 4;
    }
    
    jfTxBuf[p] = 0x08; p += 1; // 
    
    jfBusy = 1; 
    HAL_UART_Transmit_DMA(&huart7, jfTxBuf, p); 
}

/* DMA ??????:?? */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == UART7) {
        jfBusy = 0;
    }
}


void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == UART7) {
        jfBusy = 0;
    }
}